<?
	function isAllowed($package) {
		if ($package == 'sk.halmi.fbeditplus' 
			|| $package == 'sk.halmi.fbedit' 
			|| $package == 'com.skitapps.bbeditor') {
			return true;
		} else {
			return false;
		}
	}

?>

package sk.halmi.fbeditplus.helper;

public final class Constants {
	//X31CV8KBREBCZIL8UMX6
	public static final String flurryID = "S7WLCVAWIUQ3HATY4EHT";
    public final static String PREFS_NAME = "frozenbubbleedit";

	public static final int MSG_NO_NETWORK = 0;
	public static final int MSG_DONE = 1;
	public static final int MSG_DOWNLOAD_DONE = 2;
	public static final int MSG_INSERT = 3; 
	public static final int MSG_UPDATE = 4;

	public static final int EDIT = 0;
	public static final int PLAY = 1;

}
